# Car Evaluation System

**CODETECH Internship - Task 4**

**Author:** Shaik Rehaman

## Project Description
This project uses Machine Learning to predict car acceptability
based on buying price, maintenance cost, number of doors,
passenger capacity, luggage boot size, and safety.

## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Joblib

## Machine Learning Algorithms
1. Decision Tree Classifier
2. Random Forest Classifier

## Dataset
UCI Car Evaluation Dataset.

## Project Features
- Dataset loading and cleaning
- Exploratory Data Analysis
- Model training and comparison
- Accuracy evaluation
- Confusion matrix
- Sample car prediction
- Trained model saving

## How to Run
1. Open Car_Evaluation_System.ipynb in Google Colab.
2. Run all cells.
3. Check the models and outputs folders.

## Note
Model performance is measured using a held-out test dataset.
